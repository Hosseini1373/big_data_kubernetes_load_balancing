
############################################################
# Imports
############################################################
import json
import os
import pickle

import PyPDF2
import pandas as pd
from flask import Flask,request
import logging
from io import StringIO
import sys
from flask import Flask, jsonify
from os import path, walk
from haystack.document_stores import FAISSDocumentStore
from haystack.utils import print_documents
from my_model import MODELLFQA


############################################################
# Flask Initialization
############################################################
extra_dirs = ['.']
extra_files = extra_dirs[:]
for extra_dir in extra_dirs:
    for dirname, dirs, files in walk(extra_dir):
        for filename in files:
            filename = path.join(dirname, filename)
            if path.isfile(filename):
                extra_files.append(filename)

app = Flask(__name__, static_folder = 'templates')
port = int(os.environ.get('PORT', 5000))
logging.basicConfig(format="%(levelname)s - %(name)s -  %(message)s", level=logging.WARNING)
logging.getLogger("haystack").setLevel(logging.INFO)






# ############################################################
# # Model Initialization
# ############################################################
my_model={}

def initializeModel():
    if './faiss_document_store.db' in extra_files:
        return "The model is already initialized"
    
    global my_model
    if my_model:
        return "The model is already initialized"
    
    my_model=MODELLFQA()    
    my_model.initializeModel()
    return "Initialized the model"




############################################################
# APIS
############################################################
@app.route('/query', methods=['GET'])
def query_result():
    query = request.args.get('query')
    res=my_model.pipe.run(query=query, params={"Retriever": {"top_k": 3}})
    buffer = StringIO()
    sys.stdout = buffer
    print_documents(res, max_text_len=512)
    print_output = buffer.getvalue()
    sys.stdout = sys.__stdout__
    res_json={"queryResult":print_output}
    response = jsonify(res_json)
    #to allow cross origin ajax calls:
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response



@app.route('/init', methods=['GET'])
def initialize():    
    return 0
   

# @app.route('/existhash', methods=['GET'])
# def existhash(hashes):
#     if os.path.isfile('embedding_hashes.csv'):
#         with open('embeddings_available.json', 'w') as f:
#             x = json.load(f)
#         if hashes in x['hash']:
#             return True # is in list, no need to redo
#
#         x['hash'].append(hashes)
#         json.dump(x,f)
#     else:
#         x = {}
#         with open('embeddings_available.json', 'w') as f:
#             x['hash'] = [hashes]
#             json.dump(x, f)
#
#     return False


@app.route('/')
def engine(hashes):
    #print("These are the files: ",extra_files)
    "Welcome to our Game of Thrones Answering machine"
    res=initializeModel(hashes)
    return res

@app.route('/pdf')
def pdf_to_txt(file):
    # Open the PDF File
    pdf_file = open(file, 'rb')  # Replace with your PDF file path

    # Create a PDF Reader Object
    pdf_reader = PyPDF2.PdfReader(pdf_file)

    # Get the total number of pages in the document
    total_pages = len(pdf_reader.pages)

    # Extract text from each page
    pdf_text = []

    for page in range(total_pages):
        text = pdf_reader.pages[page].extract_text()
        pdf_text.append(text)

    # Close the PDF File
    pdf_file.close()

    with open(r"tester.txt", "w", encoding='utf_8') as f2:
        f2.write(str(pdf_text))
    return 0

############################################################
# Server configuration
############################################################
# from waitress import serve
# serve(app, host='127.0.0.1', port=5000,clear_untrusted_proxy_headers = False)

'''
if __name__ == '__main__':
    from waitress import serve
    app.run(host='0.0.0.0', port=port, debug=True, extra_files=extra_files)
    #serve(app, host='127.0.0.1', port=5000)
'''