
############################################################
# Imports
############################################################
import os
import pickle

from flask import Flask
import logging
from io import StringIO
import sys
from flask import Flask, render_template,jsonify
from os import path, walk
import json
import pandas as pd
from haystack.document_stores import FAISSDocumentStore
from haystack.utils import convert_files_to_docs, fetch_archive_from_http, clean_wiki_text
from haystack.nodes import DensePassageRetriever
from haystack.utils import print_documents
from haystack.pipelines import DocumentSearchPipeline
from haystack.nodes import Seq2SeqGenerator
from haystack.pipelines import GenerativeQAPipeline



class MODELLFQA:
    def __init__(self, hash):
        self.pipe = {}
        self.hash = hash

    def initializeModel(self):
        #newly added for checkhash, creates the neccesary json file if nonexistent
        if not self.existhash(self.hash):
            document_store = FAISSDocumentStore(embedding_dim=128, faiss_index_factory_str="Flat")
            # Let's first get some files that we want to use
            doc_dir = "data/tutorial12"
            s3_url = "https://s3.eu-central-1.amazonaws.com/deepset.ai-farm-qa/datasets/documents/wiki_gameofthrones_txt12.zip"
            fetch_archive_from_http(url=s3_url, output_dir=doc_dir)

            # Convert files to dicts
            docs = convert_files_to_docs(dir_path=doc_dir, clean_func=clean_wiki_text, split_paragraphs=True)

            # Now, let's write the dicts containing documents to our DB.
            document_store.write_documents(docs)

            retriever = DensePassageRetriever(
                document_store=document_store,
                query_embedding_model="vblagoje/dpr-question_encoder-single-lfqa-wiki",
                passage_embedding_model="vblagoje/dpr-ctx_encoder-single-lfqa-wiki",
            )
            document_store.update_embeddings(retriever)
            document_store.save(index_path = 'indexes')
        else:
            print("reading from saved model:")
            document_store = FAISSDocumentStore(faiss_index_path="indexes", faiss_config_path="indexes.json")
            document_store = FAISSDocumentStore.load(index_path="indexes")

            retriever = DensePassageRetriever(
                document_store=document_store,
                query_embedding_model="vblagoje/dpr-question_encoder-single-lfqa-wiki",
                passage_embedding_model="vblagoje/dpr-ctx_encoder-single-lfqa-wiki",
            )        #todo: load the retriever
        #retriever.save("my_retriever.joblib")
        # """Before we blindly use the `DensePassageRetriever` let's empirically test it to make sure a simple search indeed finds the relevant documents."""
        # p_retrieval = DocumentSearchPipeline(retriever)
        # res = p_retrieval.run(query="Tell me something about Arya Stark?", params={"Retriever": {"top_k": 10}})
        # print_documents(res, max_text_len=512)
        generator = Seq2SeqGenerator(model_name_or_path="vblagoje/bart_lfqa")
        self.pipe = GenerativeQAPipeline(generator, retriever)
        #Todo: Saving the model doesn't work
        # #save the model:
        # # save the method as pickle using dill 
        print(6)
        # import dill;
        # dill.dump(pipe, open('use_dill', 'wb'))
        # # save the session as pickle file 
        # dill.dump_session('dill_session.pkl')

    def existhash(hashes):
        if os.path.isfile('embedding_hashes.csv'):
            with open('embeddings_available.json', 'w') as f:
                x = json.load(f)
            if hashes in x['hash']:
                return True  # is in list, no need to redo

            x['hash'].append(hashes)
            json.dump(x, f)
        else:
            x = {}
            with open('embeddings_available.json', 'w') as f:
                x['hash'] = [hashes]
                json.dump(x, f)

        return False